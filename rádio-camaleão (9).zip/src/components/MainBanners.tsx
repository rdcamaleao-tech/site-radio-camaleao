import React, { useState, useEffect } from 'react';
import { useRadio } from '../context/RadioContext';
import { BANNER_PRINCIPAL_BASE64, BANNER_SECUNDARIO_BASE64, DEFAULT_MAIN_BANNER, DEFAULT_STRIP_BANNER } from '../data/defaultBanners';

export const MainBanners: React.FC = () => {
  const { settings } = useRadio();

  const rawBanner1 = settings.images?.mainBannerUrl;
  const rawBanner2 = settings.images?.stripBannerUrl;

  const getValidBanner1 = (url?: string) => {
    if (!url || url.includes('fbcdn.net') || url.includes('unsplash.com') || url === '/banners/banner_principal.jpg') {
      return DEFAULT_MAIN_BANNER || BANNER_PRINCIPAL_BASE64;
    }
    return url;
  };

  const getValidBanner2 = (url?: string) => {
    if (!url || url.includes('fbcdn.net') || url.includes('unsplash.com') || url === '/banners/banner_secundario.jpg') {
      return DEFAULT_STRIP_BANNER || BANNER_SECUNDARIO_BASE64;
    }
    return url;
  };

  const [banner1Src, setBanner1Src] = useState(() => getValidBanner1(rawBanner1));
  const [banner2Src, setBanner2Src] = useState(() => getValidBanner2(rawBanner2));

  useEffect(() => {
    setBanner1Src(getValidBanner1(rawBanner1));
  }, [rawBanner1]);

  useEffect(() => {
    setBanner2Src(getValidBanner2(rawBanner2));
  }, [rawBanner2]);

  return (
    <div className="w-full max-w-[1900px] flex flex-col gap-6">
      {/* BANNER 1 (1900x900) */}
      <div className="w-full overflow-hidden rounded-2xl border border-[#232633] shadow-[0_15px_40px_rgba(0,0,0,0.8)] relative bg-[#12141a]">
        <div className="relative w-full aspect-[1900/900] max-h-[900px] overflow-hidden">
          <img
            src={banner1Src}
            alt={`${settings.radio.name} Banner Principal`}
            referrerPolicy="no-referrer"
            onError={() => {
              if (banner1Src !== BANNER_PRINCIPAL_BASE64) {
                setBanner1Src(BANNER_PRINCIPAL_BASE64);
              }
            }}
            className="w-full h-full object-cover object-center transition-all duration-300"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/25 via-transparent to-transparent pointer-events-none" />
        </div>
      </div>

      {/* BANNER 2 (2160x403 / 1900x350) */}
      <div className="w-full overflow-hidden rounded-2xl border border-[#232633] shadow-[0_10px_30px_rgba(0,0,0,0.7)] relative bg-[#12141a]">
        <div className="relative w-full aspect-[2160/403] max-h-[400px] overflow-hidden">
          <img
            src={banner2Src}
            alt={`${settings.radio.name} Banner Secundário`}
            referrerPolicy="no-referrer"
            onError={() => {
              if (banner2Src !== BANNER_SECUNDARIO_BASE64) {
                setBanner2Src(BANNER_SECUNDARIO_BASE64);
              }
            }}
            className="w-full h-full object-cover object-center"
          />
        </div>
      </div>
    </div>
  );
};

