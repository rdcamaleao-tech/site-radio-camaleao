import React, { useState, useEffect } from 'react';
import { useRadio } from '../context/RadioContext';
import { Radio, AlertTriangle, Sparkles, Volume2 } from 'lucide-react';

const defaultBannerImg = '/banners/banner_principal.jpg';
const defaultStripBannerImg = '/banners/banner_secundario.jpg';

export const MainBanners: React.FC = () => {
  const { settings } = useRadio();

  // Garante o uso dos arquivos permanentes caso os links do Facebook expirem ou estejam salvos no cache
  const rawBanner1 = settings.images?.mainBannerUrl;
  const rawBanner2 = settings.images?.stripBannerUrl;

  const banner1Url = (!rawBanner1 || rawBanner1.includes('fbcdn.net') || rawBanner1.includes('unsplash.com'))
    ? defaultBannerImg
    : rawBanner1;

  const banner2Url = (!rawBanner2 || rawBanner2.includes('fbcdn.net') || rawBanner2.includes('unsplash.com'))
    ? defaultStripBannerImg
    : rawBanner2;

  const [banner1Error, setBanner1Error] = useState(false);
  const [banner2Error, setBanner2Error] = useState(false);

  useEffect(() => {
    setBanner1Error(false);
  }, [banner1Url]);

  useEffect(() => {
    setBanner2Error(false);
  }, [banner2Url]);

  return (
    <div className="w-full max-w-[1900px] flex flex-col gap-6">
      {/* BANNER 1 (1900x900) */}
      <div className="w-full overflow-hidden rounded-2xl border border-[#232633] shadow-[0_15px_40px_rgba(0,0,0,0.8)] relative bg-[#12141a]">
        <div className="relative w-full aspect-[1900/900] max-h-[900px] overflow-hidden">
          {!banner1Error ? (
            <img
              src={banner1Url}
              alt={`${settings.radio.name} Banner Principal`}
              referrerPolicy="no-referrer"
              onError={() => setBanner1Error(true)}
              className="w-full h-full object-cover object-center transition-all duration-300"
            />
          ) : (
            <div className="w-full h-full relative flex flex-col items-center justify-center p-6 sm:p-12 text-center bg-gradient-to-br from-[#12141a] via-[#1a1c26] to-[#0a0b0e] overflow-hidden">
              {/* Luzes decorativas de fundo */}
              <div className="absolute -top-24 -left-24 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
              
              <div className="relative z-10 flex flex-col items-center max-w-2xl">
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs sm:text-sm font-black uppercase tracking-wider mb-4 shadow-lg">
                  <Sparkles className="w-4 h-4" />
                  <span>{settings.radio.frequency} • Transmissão Oficial HD</span>
                </div>

                <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight uppercase mb-3">
                  {settings.radio.name}
                </h2>

                <p className="text-sm sm:text-lg text-slate-300 font-medium max-w-xl mb-6">
                  {settings.radio.slogan}
                </p>

                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-black/50 border border-amber-500/30 text-amber-400 text-xs">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>O link externo do Facebook expirou (Erro 403). Faça o upload do arquivo no Painel ADM para ficar permanente.</span>
                </div>
              </div>
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/25 via-transparent to-transparent pointer-events-none" />
        </div>
      </div>

      {/* BANNER 2 (2160x403 / 1900x350) */}
      <div className="w-full overflow-hidden rounded-2xl border border-[#232633] shadow-[0_10px_30px_rgba(0,0,0,0.7)] relative bg-[#12141a]">
        <div className="relative w-full aspect-[2160/403] max-h-[400px] overflow-hidden">
          {!banner2Error ? (
            <img
              src={banner2Url}
              alt={`${settings.radio.name} Banner Secundário`}
              referrerPolicy="no-referrer"
              onError={() => setBanner2Error(true)}
              className="w-full h-full object-cover object-center"
            />
          ) : (
            <div className="w-full h-full relative flex items-center justify-between px-6 sm:px-12 py-4 bg-gradient-to-r from-[#0d0e12] via-[#161822] to-[#0d0e12] border border-amber-500/20">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
                  <Radio className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <h3 className="text-base sm:text-xl font-black text-white tracking-wide uppercase">
                    {settings.radio.name} • {settings.radio.frequency}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-400 font-medium">
                    Sintonize sua melhor companhia musical 24 Horas no Ar
                  </p>
                </div>
              </div>

              <div className="hidden sm:flex items-center gap-3">
                <span className="text-xs font-mono px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 font-bold flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Ao Vivo em 128 Kbps HD</span>
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
